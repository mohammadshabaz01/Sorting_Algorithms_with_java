package org.algo.sort;

public class MergeSort extends Sort {

    @Override
    public int[] sort(int[] inputElements) {
        return new int[0];
    }

    @Override
    public void sort(String inputFile, String outputFile) {

    }
}
