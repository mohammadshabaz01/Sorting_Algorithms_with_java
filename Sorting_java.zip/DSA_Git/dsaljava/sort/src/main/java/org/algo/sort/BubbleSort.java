package org.algo.sort;


import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class BubbleSort extends Sort {
	
	@Override
	public int[] sort(int[] inputElements) {
		for(int i=0;i<inputElements.length-1;i++) {
			for(int j=0;j<inputElements.length-1-i;j++) {
				if(inputElements[j] >inputElements[j+1]) {
				//Swapping
				int temp = inputElements[j];
				inputElements[j] =inputElements[j+1];
				inputElements[j+1] =temp;
				}
			}
		}
		System.out.println("The elements are sorted by Bubble Sort! "+Arrays.toString(inputElements));
		System.out.println("kindly check the output File! ");
		
		// TODO Auto-generated method stub
		return inputElements;
	}

	@Override
	public void sort(String inputFile, String outputFile) {
		// TODO Auto-generated method stub
			try {
				BufferedReader bf =new BufferedReader(new FileReader(inputFile));
				
				String line =bf.readLine();
				System.out.print("The input unsorted elements are : ");
				System.out.println(line);
				String[] strArray=line.split(",");
				System.out.println("File is Succesfully readed !");
				
				final int size=strArray.length;
				int[] arr=new int[size];
				for(int i=0;i<size;i++) {
					arr[i]= Integer.parseInt(strArray[i]);
				}
				System.out.print("The array of given integer element's is ");
				System.out.println(Arrays.toString(arr));
				
				int returnArr[]=sort(arr);
				
				bf.close();
				
				FileWriter wr = new FileWriter(outputFile);
				wr.write("The final sorted array of elements through BubbleSort is : ");
				wr.write(Arrays.toString(returnArr));
				wr.close();
			}
							
			catch(FileNotFoundException i) {
				System.out.println("kindly provide the appropriate path for the given .txt(Input/Output)Files : "+i);
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch(NumberFormatException y) {
				System.out.println("data(Elements) in the txt file should be systematic! " + y);
			}
		
	
	}
}
