package org.algo.sort;

public class SortAdapter {
    public static Sort getSortObject(String sortType) {
    	Sort s = null;
    	

    	switch(sortType) {
    	case("BubbleSort"):{
    		s = new BubbleSort();
    		break;
    	}
    	case("SelectionSort"):{
    		s = new SelectionSort();
    		break;
    	}
    	case("InsertionSort"):{
    		s = new InsertionSort();
    		break;
    	}

    	default:
    	    System.out.println("kindly insert through only given sorting's");
    	    break;
    	}
    	return s;
    }
   	
}