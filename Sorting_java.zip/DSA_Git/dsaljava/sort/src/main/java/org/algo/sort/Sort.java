package org.algo.sort;

public abstract class Sort implements ISort{

    private String inputFile;

    private String outputFile;

}
