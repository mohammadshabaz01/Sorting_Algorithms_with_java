package org.algo.sort;
import java.util.Scanner;
public class Main  {
	public static void main(String[] args) {
		BubbleSort bn = new BubbleSort();
		SelectionSort sn =new SelectionSort();
		InsertionSort in = new InsertionSort();
		System.out.println("Main is running");
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the sorting type");
		String sortName =sc.nextLine();
//		System.out.println("kindly provides the input and output file's(.txt)");
//		System.out.println("U can pass the path of the files with there names.extension! ");
//		System.out.println("Enter the input file");
//		String inputFile = sc.nextLine();
//		System.out.println("Enter the OutputFile");
//		String outputFile = sc.nextLine();
		
		String inputFile ="G:\\Git\\DSA_Git\\dsaljava\\sort\\src\\InputFile.txt";
		String outputFile = "G:\\Git\\DSA_Git\\dsaljava\\sort\\src\\OutputFile.txt";
		//change this input/output file location accordingly.
		new SortAdapter();
		SortAdapter.getSortObject(sortName);
		sc.close();
		if(sortName.equals("BubbleSort")) {
			bn.sort(inputFile,outputFile);
		}
		else if(sortName.equals("SelectionSort")) {
			sn.sort(inputFile,outputFile);
		}
		else if(sortName.equals("InsertionSort")) {
			in.sort(inputFile,outputFile);
		}
	}

}

