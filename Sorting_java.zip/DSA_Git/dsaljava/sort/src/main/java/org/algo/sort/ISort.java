package org.algo.sort;

interface ISort {

    public int [] sort(int [] inputElements);

    public void sort(String inputFile, String outputFile);


}
