package org.dei.client;

import org.algo.sort.*;



public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}